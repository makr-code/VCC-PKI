BEGIN TRANSACTION;
CREATE TABLE audit_log (
                            id INTEGER PRIMARY KEY AUTOINCREMENT,
                            timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                            action TEXT NOT NULL,
                            user_id TEXT,
                            resource_type TEXT,
                            resource_id TEXT,
                            details TEXT,
                            ip_address TEXT
                        );
INSERT INTO "audit_log" VALUES(1,'2025-10-02 07:35:18','health_check','system',NULL,NULL,'{"overall_status": "warning", "warnings_count": 4, "errors_count": 0}','localhost');
CREATE TABLE certificates (
                            id INTEGER PRIMARY KEY AUTOINCREMENT,
                            subject TEXT NOT NULL,
                            serial_number TEXT UNIQUE NOT NULL,
                            status TEXT DEFAULT 'valid',
                            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                            expires_at TIMESTAMP NOT NULL,
                            certificate_pem TEXT,
                            metadata TEXT
                        );
INSERT INTO "certificates" VALUES(1,'CN=web-portal.brandenburg.de','1001','valid','2025-10-02 07:35:18','2026-10-02 09:35:18.240389',NULL,NULL);
INSERT INTO "certificates" VALUES(2,'CN=service-auth.vcc.local','1002','valid','2025-10-02 07:35:18','2026-03-31 09:35:18.240412',NULL,NULL);
INSERT INTO "certificates" VALUES(3,'CN=payment-gateway.vcc.local','1003','expiring','2025-10-02 07:35:18','2025-11-01 09:35:18.240413',NULL,NULL);
INSERT INTO "certificates" VALUES(4,'CN=old-service.vcc.local','1004','revoked','2025-10-02 07:35:18','2025-12-31 09:35:18.240414',NULL,NULL);
CREATE TABLE system_config (
                            key TEXT PRIMARY KEY,
                            value TEXT,
                            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                        );
CREATE TABLE vcc_services (
                            id INTEGER PRIMARY KEY AUTOINCREMENT,
                            name TEXT UNIQUE NOT NULL,
                            url TEXT NOT NULL,
                            status TEXT DEFAULT 'unknown',
                            last_check TIMESTAMP,
                            metadata TEXT,
                            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                        );
INSERT INTO "vcc_services" VALUES(1,'Authentication Service','https://auth.vcc.local','online','2025-10-02 07:35:18',NULL,'2025-10-02 07:35:18');
INSERT INTO "vcc_services" VALUES(2,'Payment Gateway','https://pay.vcc.local','online','2025-10-02 07:35:18',NULL,'2025-10-02 07:35:18');
INSERT INTO "vcc_services" VALUES(3,'Document Service','https://docs.vcc.local','offline','2025-10-02 07:35:18',NULL,'2025-10-02 07:35:18');
INSERT INTO "vcc_services" VALUES(4,'Notification Hub','https://notify.vcc.local','online','2025-10-02 07:35:18',NULL,'2025-10-02 07:35:18');
INSERT INTO "vcc_services" VALUES(5,'Argus Monitoring','https://argus.vcc.local','online','2025-10-02 07:35:18',NULL,'2025-10-02 07:35:18');
INSERT INTO "vcc_services" VALUES(6,'Covina Analytics','https://covina.vcc.local','maintenance','2025-10-02 07:35:18',NULL,'2025-10-02 07:35:18');
INSERT INTO "vcc_services" VALUES(7,'Clara Compliance','https://clara.vcc.local','online','2025-10-02 07:35:18',NULL,'2025-10-02 07:35:18');
INSERT INTO "vcc_services" VALUES(8,'Veritas Verification','https://veritas.vcc.local','online','2025-10-02 07:35:18',NULL,'2025-10-02 07:35:18');
DELETE FROM "sqlite_sequence";
INSERT INTO "sqlite_sequence" VALUES('certificates',4);
INSERT INTO "sqlite_sequence" VALUES('vcc_services',8);
INSERT INTO "sqlite_sequence" VALUES('audit_log',1);
COMMIT;
